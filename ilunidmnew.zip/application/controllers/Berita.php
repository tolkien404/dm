<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Berita extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $this->load->view('user/v_berita');
    }

    public function detail() {
        $this->load->view('user/v_beritadetail');
    }
}
