<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller {

	public function __construct() {
		parent::__construct();
	}

	public function adart() {
		$this->load->view('user/v_adart');
	}

	public function sejarah() {
		$this->load->view('user/v_sejarah');
	}

	public function visimisi() {
		$this->load->view('user/v_visimisi');
	}

	public function peraturan() {
		$this->load->view('user/v_peraturan');
	}

	public function kepengurusan() {
		$this->load->view('user/v_kepengurusan');
	}
// 
}
