    <?php
    class Buku extends CI_Controller{
        public function __construct() {
            parent::__construct();
            $this->load->library('session');
            $this->general->cekAdminLogin();
            $this->load->helper('text');
            $this->_module='admin';
            $this->load->model('admin/m_buku','mbuku');
            $this->load->model('admin/m_kategori','mkategori');
            $this->load->model('admin/m_distributor','distributor');
        }
        public function index()
        {
            $data = array(
                'username' => $this->session->userdata('username'),
                'data' => $this->mbuku->getBuku(),
                'kategori' => $this->mkategori->getKategori());
            $this->load->view($this->_module.'/buku/v_buku',$data);
        }
        public function post()
        {
            $data = array(
                'username' => $this->session->userdata('username'),
                'kategori' => $this->mkategori->getKategori()
                );
            $this->load->view($this->_module.'/buku/post', $data);
        }
        public function tambah()
        {
            $this->load->library('upload');
            $nmfile = "file_".time(); //nama file + fungsi time
            $config['upload_path'] = './assets/uploads/'; //Folder untuk menyimpan hasil upload
            $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
            $config['max_size'] = '3072'; //maksimum besar file 3M
            $config['max_width']  = '5000'; //lebar maksimum 5000 px
            $config['max_height']  = '5000'; //tinggi maksimu 5000 px
            $config['file_name'] = $nmfile; //nama yang terupload nantinya

            $this->upload->initialize($config);
            if($_FILES['filefoto']['name'])
            {
                if ($this->upload->do_upload('filefoto'))
                {
                    $gbr = $this->upload->data();
                    $data = array(

                        'id_buku' => $this->input->post('?'),
                        'id_kategori' => $this->input->post('i-kateg'),
                        'judul' => $this->input->post('i-judul'),
                        'gambar' => $gbr['file_name'],
                        'noisbn' => $this->input->post('i-noisbn'),
                        'penulis' => $this->input->post('i-penulis'),
                        'penerbit' => $this->input->post('i-penerbit'),
                        'tahun' => $this->input->post('i-tahun'),
                        'qty' => $this->input->post('i-qty'),
                        'harga_pokok' => $this->input->post('i-harga_pokok'),
                        'harga_jual' => $this->input->post('i-harga_pokok')+($this->input->post('i-harga_pokok')*$this->input->post('i-ppn')/100)-(($this->input->post('i-harga_pokok')+($this->input->post('i-harga_pokok')*$this->input->post('i-ppn')/100))*$this->input->post('i-diskon')/100),
                        'ppn' => $this->input->post('i-ppn'),
                        'diskon' => $this->input->post('i-diskon'),
                        'create' => date('Y-m-d h:i:s')
                        );

                    $this->mbuku->insert($data); //akses model untuk menyimpan ke database
                    //dibawah ini merupakan code untuk resize
                    $config2['image_library'] = 'gd2';
                    $config2['source_image'] = $this->upload->upload_path.$this->upload->file_name;
                    $config2['new_image'] = './assets/hasil_resize/'; // folder tempat menyimpan hasil resize
                    $config2['maintain_ratio'] = TRUE;
                    $config2['width'] = 100; //lebar setelah resize menjadi 100 px
                    $config2['height'] = 100; //lebar setelah resize menjadi 100 px
                    $this->load->library('image_lib',$config2);

                    //pesan yang muncul jika resize error dimasukkan pada session flashdata
                    if ( !$this->image_lib->resize()){
                        $this->session->set_flashdata('errors', $this->image_lib->display_errors('', ''));
                    }
                    //pesan yang muncul jika berhasil diupload pada session flashdata
                    $this->session->set_flashdata('pesan', "<div class=\"col-md-12\"><div class=\"alert alert-success\" id=\"alert\">Upload gambar berhasil !!</div></div>");
                    redirect('admin/buku'); //jika berhasil maka akan ditampilkan view upload
                }else{
                    //pesan yang muncul jika terdapat error dimasukkan pada session flashdata
                    $this->session->set_flashdata('pesan', "<div class=\"col-md-12\"><div class=\"alert alert-danger\" id=\"alert\">Gagal upload gambar !!</div></div>");
                    redirect('admin/post'); //jika gagal maka akan ditampilkan form upload
                }
            }
        }

        public function ubah()
        {
            $id = $this->input->post('i-id_buku');
            $data = array(
                'id_buku' => $this->input->post('i-id_buku'),
                'judul' => $this->input->post('i-judul'),
                'id_kategori' => $this->input->post('i-kateg'),
                'penulis' => $this->input->post('i-penulis'),
                'penerbit' => $this->input->post('i-penerbit'),
                'harga_pokok' => $this->input->post('i-harga_pokok'),
                'harga_jual' => $this->input->post('i-harga_pokok')+($this->input->post('i-harga_pokok')*$this->input->post('i-ppn')/100)-(($this->input->post('i-harga_pokok')+($this->input->post('i-harga_pokok')*$this->input->post('i-ppn')/100))*$this->input->post('i-diskon')/100),
                'ppn' => $this->input->post('i-ppn'),
                'diskon' => $this->input->post('i-diskon'),
                'qty' => $this->input->post('i-qty'),
                'tahun' => $this->input->post('i-tahun'),
                'update' => date('Y-m-d h:i:s')
                );
            $this->mbuku->update($data,$id);
            $this->session->set_flashdata('notif','<div class="alert alert-success" role="alert"> Data Berhasil diubah <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/buku');
        }
        public function hapus()
        {
            $id = $this->uri->segment(4);
            $this->mbuku->delete($data, $id);
            redirect('admin/buku');
        }

    }

