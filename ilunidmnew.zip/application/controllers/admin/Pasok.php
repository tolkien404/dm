<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pasok extends CI_Controller{

  public function __construct() {
    parent::__construct();
    $this->load->library('session');
    $this->general->cekAdminLogin();
    $this->load->helper('text');
    $this->_module='admin';
    $this->load->model('admin/m_pasok','mpasok');
    $this->load->model('admin/m_buku','mbuku');
    $this->load->model('admin/m_distributor','mdistributor');
  }

  public function index()
  {
    $data = array(
      'username' => $this->session->userdata('username'),
      'data' => $this->mpasok->getPasok()
      );
    $this->load->view($this->_module.'/pasok/v_pasok',$data);
  }

  public function post()
  {
    $data = array(
      'username' => $this->session->userdata('username'),
      'buku' => $this->mbuku->getBuku(),
      'distributor' => $this->mdistributor->getDistributor()
      );
    $this->load->view($this->_module.'/pasok/post',$data);
  }

  public function tambah()
  {
    $data = array(
      'id_pasok' => $this->input->post('i-id_pasok'),
      'id_distributor' => $this->input->post('i-nama_distributor'),
      'id_buku' => $this->input->post('i-judul'),
      'qty' => $this->input->post('i-qty'),
      'tanggal' => date('Y-m-d H:i:s'),
      'create' => date('Y-m-d H:i:s')
      );
    $this->mpasok->insert($data);
    redirect('admin/Pasok');

  }
  public function ubah() {
    $id = $this->input->post('i-id_pasok');
    $data = array(
      'id_pasok' => $this->input->post('i-id_pasok'),
      'qty' => $this->input->post('i-qty'),
      'update' => date('Y-m-d H:i:s')
      );
    $this->mpasok->update($data,$id);
    redirect('admin/Pasok');
  }

  function pdf()
  {
    $this->load->library('cfpdf');
    $pdf=new FPDF('P','mm','A3');
    $pdf->AddPage();
    $pdf->SetFont('Arial','B','L');
    $pdf->SetFontSize(14);
    $pdf->Text(10, 10, 'Data Pasok Buku');
    $pdf->SetFont('Arial','B','L');
    $pdf->SetFontSize(10);
    $pdf->Cell(10, 10,'','',1);
    $pdf->Cell(10, 7, 'No', 1,0);
    $pdf->Cell(80, 7, 'Nama Distributor', 1,0);
    $pdf->Cell(100, 7, 'judul Buku', 1,0);
    $pdf->Cell(40, 7, 'Tanggal', 1,0);
    $pdf->Cell(25, 7, 'Jumlah Buku', 1,1);
        // tampilkan dari database
    $pdf->SetFont('Arial','','L');
    $data=  $this->mpasok->getPasok();
    $no=1;
    $total=0;
    foreach ($data as $r)
    {
      $pdf->Cell(10, 7, $no, 1,0);
      $pdf->Cell(80, 7, $r['nama_distributor'], 1,0);
      $pdf->Cell(100, 7, $r['judul'], 1,0);
      $pdf->Cell(40, 7, $r['tanggal'], 1,0);
      $pdf->Cell(25, 7, $r['qty'], 1,1);
      $no++;
      $total=$total+$r['qty'];
    }
        // end
    $pdf->Cell(230,7,'Total',1,0,'R');
    $pdf->Cell(25,7,$total,1,0);
    $pdf->Output();
  }
}