		<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		class dashboard extends CI_controller{
			function __construct(){
				parent::__construct();
				$this->load->library('session');
				$this->general->cekAdminLogin();
				$this->load->model('admin/m_dashboard','md');
				$this->load->helper("url");
				$this->load->helper('form');
				$this->load->helper('date');
				$this->load->helper('text');
			}
			public function index(){
				//digunakan untuk menampilkan tampilan show_view.php
				$year1 = $this->input->post('yearOne');
				$earning1 = $this->md->getTotal($year1);
				$total1= array();
				foreach ($earning1 as $tot) {
					$total1[] = $tot->total_pasok;
				}
				$bulan = $this->md->getBulan();
				$label = array();
				foreach ($bulan as $m) {
					$label[] = $m->bulan;
				}
				$Data['label'] = json_encode($label);
				$Data['tahun'] = $this->md->getTahun();
				$Data['result1'] = json_encode($total1);
				$Data['one'] = $year1;
				$data = array(
					'username' => $this->session->userdata('username'),
					'jumlah_buku' => $this->md->getTotalBuku(),
					'jumlah_kasir' => $this->md->getTotalKasir(),
					'jumlah_distributor' => $this->md->getTotalDistributor(),
					'jumlah_penjualan' => $this->md->getTotalPenjualan(),
					'jumlah_totalpasok' =>$this->md->getTotalPasokBuku(),
					'jumlah_totalstokbuku' =>$this->md->getTotalStokBuku(),
					'report' => $this->md->report()
					);
				$Data += $data;
				$this->load->view('admin/v_dashboard', $Data);
			}
			public function logout() {
				$this->session->unset_userdata('username');
				$this->session->unset_userdata('level');
				session_destroy();
				redirect('auth');
			}
		}