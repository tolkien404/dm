<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Distributor extends CI_Controller {
	//Constructor to load library, module, model, or etc.
	public function __construct() 
	{
		parent::__construct();
		$this->load->library('session');
		$this->general->cekAdminLogin();
		$this->_module = 'admin';
		$this->load->model('admin/m_distributor','mdistributor');
	}
	
	public function index()
	{
		$data = array(
			'username' => $this->session->userdata('username'),
			'data' => $this->mdistributor->getDistributor()
			);
		$this->load->view($this->_module.'/distributor/v_distributor',$data);
	}

	public function post() 
	{
		$data = array(
			'username' => $this->session->userdata('username')
			);
		$this->load->view($this->_module.'/distributor/post', $data);
	}

	public function tambah() 
	{
		$data = array(
			'id_distributor' => $this->input->post('i-id-distributor'),
			'nama_distributor' => $this->input->post('i-nama-distributor'),
			'alamat' => $this->input->post('i-alamat'),
			'telepon' => $this->input->post('i-telepon'),
			'create' => date('Y-m-d H:i:s')
			);
		$this->mdistributor->insert($data);
		redirect('admin/Distributor');
	}

	public function hapus() {
		$id = $this->uri->segment(4);
		$data = array(
			'id_distributor'=> $this->uri->segment(4),
			'delete' => date('Y-m-d H:i:s')
			);
		$this->mdistributor->delete($data,$id);
		redirect('admin/Distributor');
	}

	public function ubah() {
		$id = $this->input->post('i-id-distributor');
		$data = array(
			'id_distributor' => $this->input->post('i-id-distributor'),
			'nama_distributor' => $this->input->post('i-nama-distributor'),
			'alamat' => $this->input->post('i-alamat'),
			'telepon' => $this->input->post('i-telepon'),
			'update' => date('Y-m-d H:i:s')
			);
		$this->mdistributor->update($data,$id);
		redirect('admin/Distributor');
	}
}
