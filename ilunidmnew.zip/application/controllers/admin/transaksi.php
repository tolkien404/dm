<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class transaksi extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->general->cekAdminLogin();
        $this->_module = 'admin';
        $this->load->model('kasir/m_order','mor');
        $this->load->helper('string');
    }

    public function index()
    {
        $data = array(
            'username' => $this->session->userdata('username'),			
            'data' => $this->mor->getOrder()
            );
        $this->load->view($this->_module.'/transaksi/v_transaksi',$data);
    }
    function pdf()
    {
        $this->load->library('cfpdf');
        $pdf=new FPDF('P','mm','A3');
        $pdf->AddPage();
        $pdf->SetFont('Arial','B','L');
        $pdf->SetFontSize(14);
        $pdf->Text(10, 10, 'Data Transaksi');
        $pdf->SetFont('Arial','B','L');
        $pdf->SetFontSize(10);
        $pdf->Cell(10, 10,'','',1);
        $pdf->Cell(10, 7, 'No', 1,0);
        $pdf->Cell(80, 7, 'No Refensi', 1,0);
        $pdf->Cell(100, 7, 'Kasir', 1,0);
        $pdf->Cell(40, 7, 'Tanggal', 1,0);        
        $pdf->Cell(25, 7, 'total', 1,1);
        // tampilkan dari database
        $pdf->SetFont('Arial','','L');
        $data=  $this->mor->getOrder();
        $no=1;
        $total=0;
        foreach ($data as $r)
        {
            $pdf->Cell(10, 7, $no, 1,0);
            $pdf->Cell(80, 7, $r['no_referensi'], 1,0);
            $pdf->Cell(100, 7, $r['nama'], 1,0);
            $pdf->Cell(40, 7, $r['tanggal'], 1,0);            
            $pdf->Cell(25, 7, $r['total'], 1,1);
            $no++;
            $total=$total+$r['total'];
        }
        // end
        $pdf->Cell(230,7,'Total',1,0,'R');
        $pdf->Cell(25,7,$total,1,0);
        $pdf->Output();
    }

}