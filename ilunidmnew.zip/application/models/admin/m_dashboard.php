<?php 

class m_dashboard extends CI_Model{

	function __construct() { 
		parent::__construct(); 
	} 

	function getAllShows() {
		//select semua data yang ada pada table tbl_Show $this--->db->select("*");
		return $this->db->get('tbl_buku');
	}

	function getTotalPasokBuku(){
		$this->db->select('*');
		$this->db->from('v_totalpasok');
		$query = $this->db->get()->row();
		$ret = $query->jumlah_pasok;

		return $ret;
	}

	function getTotalStokBuku(){
		$this->db->select('*');
		$this->db->from('v_totalstokbuku');
		$query = $this->db->get()->row();
		$ret = $query->jumlah_stokbuku;

		return $ret;
	}

	function getTotalBuku(){
		$query = $this->db->from("tbl_buku")->get()->num_rows();

		return $query;
	}

	function getTotalKasir(){
		$query = $this->db->from("tbl_kasir")->get()->num_rows();

		return $query;
	}

	function getTotalDistributor(){
		$query = $this->db->from("tbl_distributor")->get()->num_rows();

		return $query;
	}

	function getTotalPenjualan(){
		$query = $this->db->from("tbl_penjualan")->get()->num_rows();

		return $query;
	}

	function report(){
		$query = $this->db->query("SELECT * from v_chart_pasok");
		
		if($query->num_rows() > 0){
			foreach($query->result() as $data){
				$hasil[] = $data;
			}
			return $hasil;
		}
	}

	public function getTotalJSON($year) {
		$sql = "SELECT total_pasok FROM v_chart_totalpasok WHERE tahun = $year ORDER BY no_bulan";
		$totals = array(); 

		while($res = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
			$totals[] = $res['total_pasok'];
		}

		$final = json_encode($totals);
		$results = preg_replace('/"([a-zA-Z]+[a-zA-Z0-9_]*)":/','$1:', $final);
		print $results;
	}
	
	public function getChartLabelJSON() {
		$sql = "SELECT DISTINCT bulan FROM v_chart_totalpasok ORDER BY no_bulan ASC";
		$months = array();

		while($res = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
			$months[] = $res['bulan'];
		}
		print json_encode($months);
	}
	
	public function getTahun(){
		$tahun = array();
		$tahun_sekarang = date('Y');
		for ($i = 2017 ; $i <= ($tahun_sekarang + 5) ; $i++) { 
			$tahun[$i] = $i;
		}

		return $tahun;
	}

	public function getBulan(){
		$this->db->select('bulan');
		$this->db->order_by('no_bulan');
		$query = $this->db->get('v_chart_totalpasok');
		return $query->result();
	}

	public function getTotal($year){
		$this->db->select('total_pasok');
		$this->db->order_by('no_bulan');
		$query = $this->db->get_where('v_chart_totalpasok', array('tahun' => $year));;
		return $query->result();
	}

}