<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_kasir extends CI_Model {

	public function getISBN($no_isbn)
	{
		$query = $this->db->get_where('tbl_buku', array('noisbn' => $no_isbn, 'delete' => NULL));
		return $query->row();
	}

	public function saveDetail($data) {
		$this->db->insert('tbl_penjualan_detail', $data);
		return TRUE;
	}

	public function save_as_new($data) {
		$res = $this->db->insert('tbl_penjualan_detail', $data);
		return $res;
	}

	public function savePenjualan($dtpenjualan)
	{
		$res = $this->db->insert('tbl_penjualan', $dtpenjualan);
		return $res;
	}
}

