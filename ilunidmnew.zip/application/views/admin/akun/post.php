<?php
$this->load->view('template/head');
?>
<link href="<?php echo base_url() ?>/assets/vendor/select2/select2-bootstrap.min.css" rel="stylesheet" />
<link href="<?php echo base_url() ?>/assets/vendor/select2/select2.css" rel="stylesheet" />
<link href="<?php echo base_url() ?>/assets/vendor/select2/select2.min.css" rel="stylesheet" />
<ol class="breadcrumb">
  <li class="breadcrumb-item"><a href="<?= base_url().'admin/akun'?>">Akun</a></li>
  <li class="breadcrumb-item active">Post</li>
</ol>
<div class="col-md-12">
  <div class="card">
    <div class="card-block">
      <h5>Tambah Data Akun</h5>
      <br>
      <form action="<?php echo base_url('admin/akun/tambah') ?>" id="formInput" method="post" enctype="multipart/form-data">
        <input type="hidden" name="i-id_kasir" class="form-control">
        <div class="form-group row">
          <label for="inputPassword3" class="col-sm-3 col-form-label">Nama</label>
          <div class="col-sm-9">
            <input type="text" required  class="form-control textbox" id="nama" name="i-nama" placeholder="Nama">
            <span class="text-warning" ></span>
          </div>
        </div>
        <div class="form-group row has-feedback">
          <label for="inputPassword3" class="col-sm-3 col-form-label">Username</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" id="i-username" name="i-username" placeholder="Username">
          </div>
        </div>
        <div class="form-group row ">
          <label for="inputPassword3" class="col-sm-3 col-form-label">Password</label>
          <div class="col-sm-9 has-feedback">
            <input type="password" class="form-control textbox" id="password" name="password" placeholder="Password">
            <i class="form-control-feedback"></i>
            <span class="text-warning" ></span>
          </div>
        </div>
        <div class="form-group row ">
          <label for="inputPassword3" class="col-sm-3 col-form-label">Password Ulang</label>
          <div class="col-sm-9 has-feedback">
            <input type="password" class="form-control" id="conf_password" name="i-password conf_password" placeholder="Password">
            <i class="form-control-feedback"></i>
            <span class="text-warning" ></span>
          </div>
        </div>
        <div class="form-group row ">
          <label for="inputPassword3" class="col-sm-3 col-form-label">status</label>
          <div class="col-sm-9">
            <select class="js-select2 form-control" id="i-status" name="i-status" style="width: 100%;" data-placeholder="Pilih Status">
              <option value='' disabled selected></option>
              <option value="Aktif">Aktif</option>
              <option value="Tidak aktif">Tidak Akti</option>
            </select>
          </div>
        </div>
        <div class="form-group row ">
          <label for="inputPassword3" class="col-sm-3 col-form-label">akses</label>
          <div class="col-sm-9">
            <select class="js-select2 form-control" id="i-akses" name="i-akses" style="width: 100%;" data-placeholder="Pilih Status">
              <option value='' disabled selected></option>
              <option value="Admin">Admin</option>
              <option value="Kasir">Kasir</option>
            </select>
          </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Telepon</label>
          <div class="col-sm-9 has-feedback">
            <input type="text" name="i-telepon" required class="form-control textbox" id="hp"  placeholder="telepon">
            <i class="form-control-feedback"></i>
            <span class="text-warning" ></span>
          </div>
        </div>
        <div class="form-group row">
          <label for="inputPassword3" class="col-sm-3 col-form-label">Alamat</label>
          <div class="col-sm-9">
            <textarea class="form-control" id="i-alamat" name="i-alamat" placeholder="Alamat"> </textarea>
          </div>
        </div>
        <div class="form-group row mb-0">
          <div class="offset-sm-3 col-sm-9">
           <input type="submit" class="btn btn-success"  name="submit" value="Simpan">
           <?php echo anchor('admin/akun','Kembali',array('class'=>'btn btn-danger'))?>
         </div>
       </div>
     </form>
   </div>
 </div>
</div>

<?php
$this->load->view('template/menu');
?>
<script>
  $("#akun").addClass('active');
  $('#formInput').submit(function(e){
      e.preventDefault();
      var valid=true;
      $(this).find('.textbox').each(function(){
        if (! $(this).val()){
          get_error_text(this);
          valid = false;
          $('html,body').animate({scrollTop: 0},"slow");
        }
        if ($(this).hasClass('no-valid')){
          valid = false;
          $('html,body').animate({scrollTop: 0},"slow");
        }
      });
      if (valid){
        swal({
          title: "Konfirmasi Simpan Data",
          text: "Data Akan di Simpan Ke Database",
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#1da1f2",
          confirmButtonText: "Yakin!",
          closeOnConfirm: false,
          showLoaderOnConfirm: true,
                  }, function () { //apabila sweet alert d confirm maka akan mengirim data ke simpan.php melalui proses ajax
                    $.ajax({
                      url: "http://194.168.2.80:8080/ukom2017/ukom2017_141510303/admin/akun/tambah",
                      type: "POST",
                        data: $('#formInput').serialize(), //serialize() untuk mengambil semua data di dalam form
                        dataType: "html",
                        success: function(){
                          setTimeout(function(){
                            swal({
                              title:"Data Berhasil Disimpan",
                              text: "Terimakasih",
                              type: "success"
                            }, function(){
                              window.location="http://194.168.2.80:8080/ukom2017/ukom2017_141510303/admin/akun/";
                            });
                          }, 2000);
                        },
                        error: function (xhr, ajaxOptions, thrownError) {
                          setTimeout(function(){
                            swal("Error", "Tolong Cek Koneksi Lalu Ulangi", "error");
                          }, 2000);}
                        });
                  });
      }
    });
</script>
<script src="<?php echo base_url() ?>/assets/vendor/select2/select2.full.min.js"></script>
<script src="<?php echo base_url() ?>/assets/vendor/select2/select2.min.js"></script>