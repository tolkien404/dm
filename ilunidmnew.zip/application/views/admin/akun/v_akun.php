<?php
$this->load->view('template/head');
?>
<ol class="breadcrumb">
  <li class="breadcrumb-item"><a href="#">Home</a></li>
</ol>
<div class="card">
  <div class="card-header">
    <h5 class="card-title">Data Akun</h5>
  </div>
  <br>
  <div class="col-md-12">
    <a href="<?php echo base_url().'admin/akun/post'?>" class="btn btn-success">Tambah Data </a>
  </div>
  <table id="dynamic-table-akun" class="table table-striped table-hover table-sm dt-responsive nowrap data">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Telepon</th>
        <th>Username</th>
        <th>Status</th>
        <th>Opsi</th>
      </tr>
    </thead>
    <tbody>
      <?php $no=1; foreach($data as $t) { ?>
      <tr>
        <td class="text-center"><?php echo $no++?></td>
        <td><?php echo $t['nama']?></td>
        <td><?php echo $t['alamat']?></td>
        <td><?php echo $t['telepon']?></td>
        <td><?php echo $t['username']?></td>
        <td><?php echo $t['akses']?></td>
        <td class="center">
          <a href="javascript:;"
          data-id-kasir="<?php echo $t['id_kasir'] ?>"
          data-nama="<?php echo $t['nama'] ?>"
          data-username="<?php echo $t['username'] ?>"
          data-alamat="<?php echo $t['alamat'] ?>"
          data-akses="<?php echo $t['akses'] ?>"
          class="edit btn btn-success btn-circle-small"
          title="Edit"
          data-toggle="modal"
          data-target="#edit-data">
          <i class="material-icons">edit</i>
        </a>
        <a href="<?= base_url().'admin/akun/hapus/'.$t['id_kasir']; ?>" title="Hapus" class="hapus delete btn btn-danger btn-circle-small">
          <i class="material-icons">delete</i>
        </a>
      </td>
    </tr>
    <?php } ?>
  </tbody>
</table>
<div class="clearfix"></div>
</div>

<?php
$this->load->view('template/menu');
?>

<div class="modal fade" id="edit-data" tabindex="-1" role="dialog" id="add_manufacture_popup" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" id="myModalLabel">Edit </h5>
        <?=$this->session->flashdata('pesan')?>
        <form action="<?php echo base_url('admin/akun/ubah') ?>" method="post" enctype="multipart/form-data">
          <p name="i-nama" id="i-nama1" ></p>
        </div>
        <div class="modal-body ">
          <input type="hidden" id="i-id_kasir" name="i-id_kasir">
          <div class="form-group row">
           <label class="col-sm-3 col-form-label">nama</label>
           <div class="col-sm-9">
             <input type="text" class="form-control" id="i-nama" name="i-nama" placeholder="nama">
           </div>
         </div>
         <div class="form-group row">
           <label class="col-sm-3 col-form-label">Username</label>
           <div class="col-sm-9">
             <input type="text" class="form-control" id="i-username" name="i-username" placeholder="Username">
           </div>
         </div>
         <div class="form-group row">
           <label class="col-sm-3 col-form-label">Alamat</label>
           <div class="col-sm-9">
             <textarea class="form-control" id="i-alamat" name="i-alamat" placeholder="Alamat"></textarea>
           </div>
         </div>
         <div class="form-group row">
           <label class="col-sm-3 col-form-label">status</label>
           <div class="col-sm-9">
             <select class="js-select2 form-control" id="i-akses" name="i-akses" style="width: 100%;" data-placeholder="Pilih Status">
              <option value='' disabled selected></option>
              <option value="Admin">Admin</option>
              <option value="Kasir">Kasir</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" title="Batal" class="btn btn-white" data-dismiss="modal">Close</button>
          <button class="btn btn-primary" title="Save" type="submit">Save changes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript">
  $("#akun").addClass('active');
  $(document).ready(function() {
    $('#edit-data').on('show.bs.modal', function (event) {
      var div = $(event.relatedTarget)
      var modal = $(this)
      modal.find('#i-id_kasir').attr("value",div.data('id-kasir'));
      modal.find('#i-nama').attr("value",div.data('nama'));
      modal.find('#i-username').attr("value",div.data('username'));
      modal.find('#i-alamat').attr("value",div.data('alamat'));
      modal.find('#i-nama1').html(div.data('nama'));
      modal.find('#i-akses').attr("value",div.data('akses'));
    });
  });
</script>
