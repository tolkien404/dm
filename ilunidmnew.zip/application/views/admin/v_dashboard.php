<?php
$this->load->view('template/head');
?>
<div class="row" style="margin-bottom:20px;">
    <div class="col-md-12">
        <div class="card-group">
            <div class="card">
                <div class="card-block text-xs-center">
                    <h4 class="text-info mb-0"><strong><?php echo $jumlah_penjualan ;?></strong></h4>
                    <small class="text-muted-light">Penjualan</small>
                </div>
            </div>
            <div class="card">
                <div class="card-block text-xs-center">
                    <h4 class="text-primary mb-0"><strong><?php echo $jumlah_buku ;?></strong></h4>
                    <small class="text-muted-light">Jumlah Buku</small>
                </div>
            </div>
            <div class="card">
                <div class="card-block text-xs-center">
                    <h4 class="text-success mb-0"><strong><?php echo $jumlah_totalstokbuku ;?></strong></h4>
                    <small class="text-muted-light">Stok Buku</small>
                </div>
            </div>
            <div class="card">
                <div class="card-block text-xs-center">
                    <h4 class="text-danger mb-0"><strong><?php echo $jumlah_totalpasok ;?></strong></h4>
                    <small class="text-muted-light">Pasok Buku</small>
                </div>
            </div>
            <div class="card">
                <div class="card-block text-xs-center">
                    <h4 class=" mb-0"><strong><?php echo $jumlah_kasir ;?></strong></h4>
                    <small class="text-muted-light">Akun</small>
                </div>
            </div>
            <div class="card">
                <div class="card-block text-xs-center">
                    <h4 class=" mb-0"><strong><?php echo $jumlah_distributor ;?></strong></h4>
                    <small class="text-muted-light">Distributor</small>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-block">
        <div class="row">
        <div class="col-md-12">
            <h2>Total Pasok</h2>
            <form class="js-form-search push-10" action="<?php echo site_url()?>admin/dashboard" method="post">
                <div class="input-group input-group-sm">
                    <select class="form-control" name="yearOne">
                        <option value='' disabled selected>Pilih Tahun</option>
                        <?php
                        foreach ($tahun as $th) {
                            echo "
                            <option value='" .$th. "'>" . $th . "</option>";
                        }
                        ?>
                    </select>
                    <div class="input-group-btn">
                        <button class="btn btn-default" type="submit"><i class="material-icons">search</i></button>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-md-9">
                    <button class="btn btn-sm btn-primary" id="save-btn">Unduh Gambar</button>
                    <button class="btn btn-sm btn-primary" id="download-pdf">Unduh PDF</button>
                </div>
            </div>
            <br>
            Grafik Total Pasokan Semua Judul Buku Per Bulan Pada Tahun <strong> <?php echo $one;?> </strong>
            <br>
            <div class="col-sm-9">
                <canvas id="demoChart" class="chart" width="600" height="350"></canvas>
            </div>
            <div class="col-sm-3">
                <div id="demoLegend"> </div>
            </div>
            <div class="col-sm-9">
                <canvas id="myChartok" width="600" height="350"></canvas>
            </div>
        </div>
        </div>
    </div>
</div>
<?php
$this->load->view('template/menu');
?>

<script type="text/javascript">
    $(document).ready(function(){
        var $globalOptions = {
            scaleFontFamily: "'Open Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif",
            scaleFontColor: '#999',
            scaleFontStyle: '600',
            tooltipTitleFontFamily: "'Open Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif",
            tooltipCornerRadius: 3,
            maintainAspectRatio: false,
            responsive: true,
            scaleLabel:
            function(label){return  label.value.toString() + ' Buku'}
        };
        var data = {
            labels: <?php echo $label; ?>,
            datasets: [
            {
                label: "Total Pasokan Buku Per Bulan, Tahun: " + <?php echo $one;?>,
                fillColor:  "rgba(44, 52, 63, 0.2)",
                strokeColor: "rgba(44, 52, 63, 1)",
                pointColor:  "rgba(44, 52, 63, 1)",
                pointStrokeColor: "#FFF",
                pointHighlightFill: "#FFF",
                pointHighlightStroke: "rgba(44, 52, 63, 1)",
                data: <?php echo $result1; ?>
            }
            ]
        };

        var ctx = document.getElementById("demoChart").getContext("2d");
        var chart = new Chart(ctx).Line(data, $globalOptions);
        $("#save-btn").click(function() {
            $("#demoChart").get(0).toBlob(function(blob) {
                saveAs(blob, "Total Pemasokan Per Bulan Tahun <?php echo $one;?>.png");
            });
        });
        document.getElementById('download-pdf').addEventListener("click", downloadPDF);

        function downloadPDF() {
            var canvas = document.querySelector('#demoChart');
            var canvasImg = canvas.toDataURL("image/png", 1.0);

            var doc = new jsPDF('landscape');
            doc.setFontSize(20);
        // doc.text(15, 15, "Total Pemasokan Per Bulan Tahun : <?php echo $one;?>");
        doc.addImage(canvasImg, 'JPEG', 10, 10, 280, 150 );
        doc.save('Total Pamasokan Per Bulan Tahun <?php echo $one;?>.pdf');
    }
    document.getElementById("demoLegend").innerHTML = chart.generateLegend();
});


</script>