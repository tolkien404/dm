<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Buku-dl</title>
    <link rel="icon" href="<?php echo site_url().'assets/img/buku-dl.png' ?>">
    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">
    <!-- Material Design Icons  -->
     <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->
    <!-- Roboto Web Font-->
     <!-- <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en" rel="stylesheet"> -->
    <?=css('material-design-kit.css')?>
    <?=css('sidebar-collapse.min.css')?>
    <?=css('style.min.css')?>
    <?=css('datatables.min.css')?>
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/iconfont/material-icons.css" />
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/vendor/DataTables/css/dataTables.bootstrap4.min.css" />
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/vendor/DataTables/Responsive/css/responsive.bootstrap4.min.css" />
    <link rel="stylesheet" href="<?php echo base_url() ?>/assets/vendor/select2/select2-bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo base_url() ?>/assets/vendor/select2/select2.css" />
    <link rel="stylesheet" href="<?php echo base_url() ?>/assets/vendor/select2/select2.min.css" />
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/vendor/sweetalert/dist/sweetalert.css" />
</head>
<body class="top-navbar">
    <!-- Navbar -->
    <nav class="navbar navbar-dark bg-primary navbar-full navbar-fixed-top">

        <!-- Toggle sidebar -->
        <button class="navbar-toggler" type="button" data-toggle="sidebar"></button>

        <!-- Brand -->
        <a href="instructor-dashboard.html" class="navbar-brand"><i class="material-icons">book</i> Buku-dl</a>
<!--
        <ul class="nav navbar-nav hidden-sm-down">
            <li class="nav-item">
                <div class="nav-stats">$591 <small>GROSS</small></div>
            </li>
            <li class="nav-item">
                <div class="nav-stats">$31 <small>TAXES</small></div>
            </li>
            <li class="nav-item">
                <div class="nav-stats">$560 <small>NET</small></div>
            </li>
        </ul>-->
        <div class="navbar-spacer"></div>
        <!-- Menu -->
        <!-- Menu -->
        <ul class="nav navbar-nav">
            <!-- User dropdown -->
            <li class="nav-item dropdown">
                            <a class="nav-link active dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="false"><?php echo $username ?></a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="Preview">
                    <a class="dropdown-item" href="<?php echo site_url('admin/dashboard/logout'); ?>">
                        <i class="material-icons">lock</i> Keluar
                    </a>
                </div>
            </li>
            <!-- // END User dropdown -->
        </ul>
    </nav>
    <!-- // END Navbar -->
    <div class="mdk-drawer-layout mdk-js-drawer-layout" push has-scrolling-region>
        <div class="mdk-drawer-layout__content">
            <div class="container-fluid">

