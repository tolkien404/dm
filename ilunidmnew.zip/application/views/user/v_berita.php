<title>Berita - Iluni Dm Unbor</title>
<?php
$this->load->view('template/header');
?>
<!-- End Site Header --> 
<!-- Start Nav Backed Header -->
<div class="nav-backed-header parallax" style="background-image:url(<?php echo base_url('assets/images/slide2.png') ?>);">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ol class="breadcrumb">
					<li><a href="<?php echo base_url().'Home' ?>">Home</a></li>
					<li class="active">Berita</li>
				</ol>
			</div>
		</div>
	</div>
</div>
<!-- End Nav Backed Header --> 
<!-- Start Page Header -->
<div class="page-header">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1>Berita</h1>
			</div>
		</div>
	</div>
</div>
<!-- End Page Header --> 
<!-- Start Content -->
<div class="main" role="main">
	<div id="content" class="content full">
		<div class="container">
			<div class="row">
				<div class="col-md-12 posts-archive">
					<article class="post">
						<div class="row">
							<div class="col-md-4 col-sm-4"> <a href="single-event.html"><img src="<?php echo base_url('assets/uploads/1.png')?>" alt="" class="img-thumbnail"></a> </div>
							<div class="col-md-8 col-sm-8">
								<h3><a href="<?php echo base_url().'Berita/Detail' ?>">Telah dilaksanakan DM 24 Unbor</a></h3>
								<span class="post-meta meta-data"> <span><i class="fa fa-calendar"></i> 30/10/2017</span><span><i class="fa fa-archive"></i>Diklat Manargasi</span></span>
								<p><?php
								$num_char = 200;
								$text = 'Assalamualaikum wr.wb, bagaimana kabar kalian? semoga baik baik saja :) dengan segala kesibukan aktifitasnya, tidak terasa berjalannya waktu yang telah kita lalui sebagai insan yang pernah menuntut ilmu di universitas kita tercinta UNIVERSITAS BOROBUDUR, dan belajar banyak hal dari organisasi dan kawan kawan di UNIVERSITAS BOROBUDUR, khususnya organisasi DIKLAT MANARGASI, alhamdulillah tidak terasa pula DIKLAT MANARGASI UNIVERSITAS BOROBUDUR sudah mencapai DM angkatan 24, yang telah di selenggarakan pada tanggal 30/10/2017, patut kita syukuri di DM 24 ini mencapai 51 anggota dan telah menjalankan berbagai kegiatan sebagai ke anggotaan yang sah, dengan demikian keluarga anggata ILUNI DM UNBOR telah bertambah menjadi XXXX, dengan telah mencapainya ILUNI DM 24 UNBOR ini semoga menambah rasa kekluargaan dan simpati kita pada Sesama dan menghasilkan Pemimpin yang berkualitas serta amanah';
								echo substr($text, 0, $num_char) . '...';
								?></p>
								<p><a href="<?php echo base_url().'Berita/Detail' ?>" class="btn btn-primary">Selengkapnya <i class="fa fa-long-arrow-right"></i></a></p>
							</div>
						</div>
					</article>
					<ul class="pagination">
						<li><a href="#"><i class="fa fa-chevron-left"></i></a></li>
						<li class="active"><a href="#">1</a></li>
						<li><a href="#">2</a></li>
						<li><a href="#">3</a></li>
						<li><a href="#">4</a></li>
						<li><a href="#">5</a></li>
						<li><a href="#"><i class="fa fa-chevron-right"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
$this->load->view('template/footer');
?>