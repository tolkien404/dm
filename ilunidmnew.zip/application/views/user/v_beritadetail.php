<title>Detail Berita - Iluni Dm Unbor</title>
<?php
$this->load->view('template/header');
?>
<!-- End Site Header --> 
<!-- Start Nav Backed Header -->
<div class="nav-backed-header parallax" style="background-image:url(<?php echo base_url('assets/images/slide2.png') ?>);">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url().'Home' ?>">Home</a></li>
          <li class="active">Detail Berita</li>
        </ol>
      </div>
    </div>
  </div>
</div>
<!-- End Nav Backed Header --> 
<!-- Start Page Header -->
<div class="page-header">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1>Detail Berita</h1>
      </div>
    </div>
  </div>
</div>
<!-- End Page Header --> 
<!-- Start Content -->
<div class="main" role="main">
    <div id="content" class="content full">
      <div class="container">
        <div class="row">
          <div class="col-md-9">
            <header class="single-post-header clearfix">
              <div class="pull-right post-comments-count"></div>
              <h2 class="post-title">Telah dilaksanakan DM 24 Unbor</h2>
            </header>
            <article class="post-content"> <span class="post-meta meta-data"><span><i class="fa fa-calendar"></i> 30/10/2017</span> <span><i class="fa fa-archive"></i> Diklat Manargasi</span></span>
              <div class="featured-image"> <img src="<?php echo base_url('assets/uploads/1.png')?>" alt=""> </div>
              <p><?php
                $num_char = 1000;
                $text = 'Assalamualaikum wr.wb, bagaimana kabar kalian? semoga baik baik saja :) dengan segala kesibukan aktifitasnya, tidak terasa berjalannya waktu yang telah kita lalui sebagai insan yang pernah menuntut ilmu di universitas kita tercinta UNIVERSITAS BOROBUDUR, dan belajar banyak hal dari organisasi dan kawan kawan di UNIVERSITAS BOROBUDUR, khususnya organisasi DIKLAT MANARGASI, alhamdulillah tidak terasa pula DIKLAT MANARGASI UNIVERSITAS BOROBUDUR sudah mencapai DM angkatan 24, yang telah di selenggarakan pada tanggal 30/10/2017, patut kita syukuri di DM 24 ini mencapai 51 anggota dan telah menjalankan berbagai kegiatan sebagai ke anggotaan yang sah, dengan demikian keluarga anggata ILUNI DM UNBOR telah bertambah menjadi XXXX, dengan telah mencapainya ILUNI DM 24 UNBOR ini semoga menambah rasa kekluargaan dan simpati kita pada Sesama dan menghasilkan Pemimpin yang berkualitas serta amanah';
                echo substr($text, 0, $num_char) . '...';
                ?>
              </p>
            </article>
            
          </div>
          <!-- Start Sidebar -->
            <div class="widget sidebar-widget">
              <div class="sidebar-widget-title">
                <h3>Post Categories</h3>
              </div>
              <ul>
                <li><a href="#">Diklat Manargasi</a> (1)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

      <?php
      $this->load->view('template/footer');
      ?>