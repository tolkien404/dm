<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Login</title>
  <link rel="icon" href="<?php echo site_url().'assets/img/buku-dl.png' ?>">
  <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
  <meta name="robots" content="noindex">

  <!-- Material Design Icons  -->
  <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

  <!-- Roboto Web Font -->
  <!-- <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en" rel="stylesheet"> -->

  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/iconfont/material-icons.css" />
  <?=css('material-design-kit.css')?>
  <link href="<?php echo base_url('assets/css/style.min.css') ?>" rel="stylesheet" type="text/css">
</head>
<body class="login">	
  <div class="row">
    <div class="col-sm-8 push-sm-1 col-md-4 push-md-4 col-lg-4 push-lg-4">
      <div class="text-xs-center m-2">
        <div class="icon-block rounded-circle">
          <i class="material-icons lock md-36 text-muted">lock</i>
        </div>  
      </div>
      <div class="card bg-transparent">
        <div class="card-header bg-white text-xs-center">
          <h4 class="card-title">Login</h4>
          <p class="card-subtitle">Access your account</p>
        </div>
        <div class="p-2">
          <?php echo form_open('login', array('class'=>'form-material m-b-1')); ?>
          <div class="form-group">
            <input type="text" name="username" id="text-form" class="form-control" placeholder="Username">
          </div>
          <div class="form-group">
            <input type="password" name="password" id="text-form" class="form-control" placeholder="Password">
          </div>
          <div class="form-group ">
            <button type="submit" class="btn btn-warning btn-block">
              <span class="btn-block-text">Login</span>
            </button>
          </div>
          <div class="text-xs-center">
          </div>
          <?php echo $this->session->flashdata('message'); //Tampilkan Pesan Jika Gagal Login ?>
          <?php echo form_close(); ?><br><br>
        </div>
      </div>
    </div>
  </div>
  <script src="<?php echo base_url('assets/js/jquery-2.0.0.min.js') ?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.js') ?>"></script>
</body>
</html>